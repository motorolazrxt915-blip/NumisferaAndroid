package com.numisfera.app
import android.os.Bundle
import android.net.Uri
import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import com.numisfera.app.media.CoinImages
import com.numisfera.app.backup.CoinBackup
import com.numisfera.app.catalog.CatalogScreen
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.numisfera.app.data.*
import com.numisfera.app.network.ConnectivityObserver
import com.numisfera.app.printing.CoinPrint
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import androidx.activity.compose.rememberLauncherForActivityResult

class MainActivity : ComponentActivity() {
 @OptIn(ExperimentalMaterial3Api::class)
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val repo = CoinRepository(NumisferaDatabase.get(this).coinDao())
  val connectivity = ConnectivityObserver(this)
  setContent {
   MaterialTheme {
    val coins by repo.observeCoins().collectAsStateWithLifecycle(initialValue = emptyList())
    val online by connectivity.observe().stateIn(lifecycleScope, SharingStarted.WhileSubscribed(5000), false).collectAsStateWithLifecycle()
    var form by remember { mutableStateOf(false) }
    var showCatalog by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val backupCoins by repo.observeCoins().collectAsStateWithLifecycle(initialValue = emptyList())
    val exportBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
     if (uri != null) lifecycleScope.launch {
      runCatching { CoinBackup.export(this@MainActivity, backupCoins, uri) }
       .onSuccess { Toast.makeText(this@MainActivity, "Copia de seguridad creada", Toast.LENGTH_LONG).show() }
       .onFailure { Toast.makeText(this@MainActivity, "Error al exportar: ${it.message}", Toast.LENGTH_LONG).show() }
     }
    }
    val importBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
     if (uri != null) lifecycleScope.launch {
      runCatching { CoinBackup.import(this@MainActivity, uri) { repo.save(it) } }
       .onSuccess { Toast.makeText(this@MainActivity, "Copia importada", Toast.LENGTH_LONG).show() }
       .onFailure { Toast.makeText(this@MainActivity, "Error al importar: ${it.message}", Toast.LENGTH_LONG).show() }
     }
    }
    Scaffold(topBar = { TopAppBar(title = { Text("Numisfera") }, actions = {
      Text(if (online) "● En línea " else "● Sin conexión ")
     }) },
     floatingActionButton = { FloatingActionButton(onClick = { form = true }) { Icon(Icons.Default.Add, "Agregar moneda") } }) { padding ->
     Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
      Text("Mi colección", style = MaterialTheme.typography.headlineMedium)
      Text("${coins.size} registro(s) guardados en este dispositivo")
      OutlinedButton(onClick = { showCatalog = true }, modifier = Modifier.fillMaxWidth()) { Text("Explorar catálogo numismático") }
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
       OutlinedButton(onClick = { exportBackup.launch("Numisfera_backup.json") }) {
        Icon(Icons.Default.SaveAlt, null); Spacer(Modifier.width(4.dp)); Text("Crear copia")
       }
       OutlinedButton(onClick = { importBackup.launch(arrayOf("application/json", "text/json", "*/*")) }) {
        Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(4.dp)); Text("Importar copia")
       }
      }
      Spacer(Modifier.height(12.dp))
      if (coins.isEmpty()) {
       Card { Column(Modifier.padding(18.dp)) {
        Text("Tu colección comienza aquí", style = MaterialTheme.typography.titleMedium)
        Text("Los registros se guardan localmente y siguen disponibles sin internet.")
        Button(onClick = { form = true }) { Text("Registrar primera moneda") }
       } }
      } else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
       items(coins, key = { it.id }) { coin ->
        Card { Column(Modifier.fillMaxWidth().padding(14.dp)) {
         Text(coin.name, style = MaterialTheme.typography.titleMedium)
         Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          PhotoPreview(coin.obverseImagePath, "Anverso")
          PhotoPreview(coin.reverseImagePath, "Reverso")
         }
         Text(listOf(coin.country, coin.year, coin.denomination).filter { it.isNotBlank() }.joinToString(" · "))
         Text(listOf(if (coin.diameterMm.isNotBlank()) "Ø ${coin.diameterMm} mm" else "", if (coin.weightGrams.isNotBlank()) "${coin.weightGrams} g" else "", coin.metal).filter { it.isNotBlank() }.joinToString(" · "))
         Text(if (coin.estimatedValue.isNotBlank()) "Valor registrado: ${coin.estimatedValue} ${coin.valueCurrency}" else "Sin valor registrado")
         Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedButton(onClick = { CoinPrint.print(this@MainActivity, coin) }) {
           Icon(Icons.Default.Print, null); Spacer(Modifier.width(5.dp)); Text("Imprimir ficha")
          }
          TextButton(onClick = { lifecycleScope.launch { repo.delete(coin.id) } }) { Text("Eliminar") }
         }
        } }
       }
      }
     }
    }
    if (form) CoinForm(this@MainActivity, { form = false }, { coin -> lifecycleScope.launch { repo.save(coin) }; form = false })
    if (showCatalog) CatalogScreen(onDismiss = { showCatalog = false }, onAdd = { coin ->
     lifecycleScope.launch {
      runCatching { repo.save(coin) }
       .onSuccess { Toast.makeText(this@MainActivity, "Agregada a tu colección", Toast.LENGTH_SHORT).show() }
       .onFailure { Toast.makeText(this@MainActivity, "No se pudo agregar: ${it.message}", Toast.LENGTH_LONG).show() }
     }
    })
   }
  }
 }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CoinForm(activity: ComponentActivity, onDismiss: () -> Unit, onSave: (CoinEntity) -> Unit) {
 var name by remember { mutableStateOf("") }; var country by remember { mutableStateOf("") }
 var year by remember { mutableStateOf("") }; var denomination by remember { mutableStateOf("") }
 var metal by remember { mutableStateOf("") }; var grade by remember { mutableStateOf("") }
 var value by remember { mutableStateOf("") }; var currency by remember { mutableStateOf("ARS") }
 var ref by remember { mutableStateOf("") }; var notes by remember { mutableStateOf("") }
 var currencySystem by remember { mutableStateOf("") }; var issueDate by remember { mutableStateOf("") }
 var diameter by remember { mutableStateOf("") }; var weight by remember { mutableStateOf("") }; var thickness by remember { mutableStateOf("") }
 var edge by remember { mutableStateOf("") }; var shape by remember { mutableStateOf("Circular") }
 var mint by remember { mutableStateOf("") }; var mintage by remember { mutableStateOf("") }; var designer by remember { mutableStateOf("") }
 var technique by remember { mutableStateOf("Acuñación") }; var orientation by remember { mutableStateOf("") }
 var variety by remember { mutableStateOf("") }; var rarity by remember { mutableStateOf("") }; var authenticity by remember { mutableStateOf("Sin verificar") }
 var gradeScale by remember { mutableStateOf("") }; var commemorative by remember { mutableStateOf(false) }
 var acquisitionDate by remember { mutableStateOf("") }; var acquisitionPrice by remember { mutableStateOf("") }; var acquisitionCurrency by remember { mutableStateOf("ARS") }
 var provenance by remember { mutableStateOf("") }; var valuationDate by remember { mutableStateOf("") }; var valuationSource by remember { mutableStateOf("") }
 var referenceSource by remember { mutableStateOf("") }
 var obversePath by remember { mutableStateOf("") }; var reversePath by remember { mutableStateOf("") }
 var choosingSide by remember { mutableStateOf("obverse") }
 val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
  if (uri != null) runCatching { CoinImages.copyIntoAppStorage(activity, uri, choosingSide) }
   .onSuccess { path -> if (choosingSide == "obverse") obversePath = path else reversePath = path }
   .onFailure { Toast.makeText(activity, "No se pudo guardar la foto", Toast.LENGTH_LONG).show() }
 }
 AlertDialog(onDismissRequest = onDismiss, title = { Text("Ficha profesional de moneda") },
  text = { Column(Modifier.heightIn(max=560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
   Text("Fotografías (se guardan en el teléfono y funcionan sin internet)")
   Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    OutlinedButton(onClick = { choosingSide = "obverse"; photoPicker.launch("image/*") }) { Text(if (obversePath.isBlank()) "Elegir anverso" else "Cambiar anverso") }
    OutlinedButton(onClick = { choosingSide = "reverse"; photoPicker.launch("image/*") }) { Text(if (reversePath.isBlank()) "Elegir reverso" else "Cambiar reverso") }
   }
   Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    PhotoPreview(obversePath, "Anverso")
    PhotoPreview(reversePath, "Reverso")
   }
   OutlinedTextField(name,{name=it},label={Text("Nombre / denominación *")},singleLine=true)
   OutlinedTextField(country,{country=it},label={Text("País o autoridad")},singleLine=true)
   OutlinedTextField(year,{year=it},label={Text("Año o período")},singleLine=true)
   OutlinedTextField(denomination,{denomination=it},label={Text("Valor facial")},singleLine=true)
   OutlinedTextField(metal,{metal=it},label={Text("Metal / composición")},singleLine=true)
   Text("Características físicas", style = MaterialTheme.typography.titleSmall)
   OutlinedTextField(diameter,{diameter=it},label={Text("Diámetro (mm)")},singleLine=true)
   OutlinedTextField(weight,{weight=it},label={Text("Peso (gramos)")},singleLine=true)
   OutlinedTextField(thickness,{thickness=it},label={Text("Grosor (mm)")},singleLine=true)
   OutlinedTextField(edge,{edge=it},label={Text("Canto (liso, estriado, leyenda…)")},singleLine=true)
   OutlinedTextField(shape,{shape=it},label={Text("Forma")},singleLine=true)
   OutlinedTextField(orientation,{orientation=it},label={Text("Orientación de cuños")},singleLine=true)
   Text("Emisión e identificación", style = MaterialTheme.typography.titleSmall)
   OutlinedTextField(currencySystem,{currencySystem=it},label={Text("Sistema monetario")},singleLine=true)
   OutlinedTextField(issueDate,{issueDate=it},label={Text("Fecha de emisión")},singleLine=true)
   OutlinedTextField(mint,{mint=it},label={Text("Ceca / autoridad acuñadora")},singleLine=true)
   OutlinedTextField(mintage,{mintage=it},label={Text("Tirada / cantidad acuñada")},singleLine=true)
   OutlinedTextField(designer,{designer=it},label={Text("Diseñador / grabador")},singleLine=true)
   OutlinedTextField(technique,{technique=it},label={Text("Técnica")},singleLine=true)
   OutlinedTextField(variety,{variety=it},label={Text("Variante / error observado")},singleLine=true)
   OutlinedTextField(rarity,{rarity=it},label={Text("Rareza (sin certificar)")},singleLine=true)
   Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
    Checkbox(checked=commemorative, onCheckedChange={commemorative=it})
    Text("Emisión conmemorativa")
   }
   OutlinedTextField(grade,{grade=it},label={Text("Conservación observada")},singleLine=true)
   OutlinedTextField(gradeScale,{gradeScale=it},label={Text("Escala (ej. Sheldon / descriptiva)")},singleLine=true)
   OutlinedTextField(authenticity,{authenticity=it},label={Text("Autenticidad (sin verificar por defecto)")},singleLine=true)
   OutlinedTextField(value,{value=it},label={Text("Valor estimado (opcional)")},singleLine=true)
   OutlinedTextField(currency,{currency=it},label={Text("Moneda de valoración (ARS, USD, EUR…)")},singleLine=true)
   Text("Adquisición y valoración", style = MaterialTheme.typography.titleSmall)
   OutlinedTextField(acquisitionDate,{acquisitionDate=it},label={Text("Fecha de adquisición")},singleLine=true)
   OutlinedTextField(acquisitionPrice,{acquisitionPrice=it},label={Text("Precio de compra")},singleLine=true)
   OutlinedTextField(acquisitionCurrency,{acquisitionCurrency=it},label={Text("Moneda de compra")},singleLine=true)
   OutlinedTextField(provenance,{provenance=it},label={Text("Procedencia / vendedor / colección")},singleLine=true)
   OutlinedTextField(valuationDate,{valuationDate=it},label={Text("Fecha de valoración")},singleLine=true)
   OutlinedTextField(valuationSource,{valuationSource=it},label={Text("Fuente de valoración")},singleLine=true)
   OutlinedTextField(ref,{ref=it},label={Text("Referencia de catálogo")},singleLine=true)
   OutlinedTextField(referenceSource,{referenceSource=it},label={Text("Fuente técnica / URL o publicación")},singleLine=true)
   OutlinedTextField(notes,{notes=it},label={Text("Descripción, procedencia adicional y observaciones")},minLines=2)
  } },
  confirmButton = { Button(enabled=name.isNotBlank(), onClick={
   onSave(CoinEntity(name=name.trim(),country=country.trim(),year=year.trim(),denomination=denomination.trim(),
    metal=metal.trim(),conditionGrade=grade.trim(),estimatedValue=value.trim(),valueCurrency=currency.trim().ifBlank{"ARS"},
    catalogReference=ref.trim(),notes=notes.trim(), obverseImagePath=obversePath, reverseImagePath=reversePath,
    currencySystem=currencySystem.trim(), issueDate=issueDate.trim(), diameterMm=diameter.trim(), weightGrams=weight.trim(),
    thicknessMm=thickness.trim(), edge=edge.trim(), shape=shape.trim(), mint=mint.trim(), mintage=mintage.trim(),
    designer=designer.trim(), technique=technique.trim(), orientation=orientation.trim(), variety=variety.trim(), rarity=rarity.trim(),
    authenticity=authenticity.trim().ifBlank { "Sin verificar" }, gradeScale=gradeScale.trim(), isCommemorative=commemorative,
    acquisitionDate=acquisitionDate.trim(), acquisitionPrice=acquisitionPrice.trim(), acquisitionCurrency=acquisitionCurrency.trim().ifBlank { "ARS" },
    provenance=provenance.trim(), valuationDate=valuationDate.trim(), valuationSource=valuationSource.trim(), referenceSource=referenceSource.trim()))
  }) { Text("Guardar") } },
  dismissButton = { TextButton(onClick=onDismiss) { Text("Cancelar") } }
 )
}

@Composable
private fun PhotoPreview(path: String, label: String) {
 val bitmap = remember(path) {
  if (path.isNotBlank()) runCatching { BitmapFactory.decodeFile(path)?.asImageBitmap() }.getOrNull() else null
 }
 Card(Modifier.width(112.dp).height(100.dp)) {
  Column(Modifier.fillMaxSize().padding(5.dp)) {
   Text(label, style = MaterialTheme.typography.labelSmall)
   if (bitmap != null) Image(bitmap, contentDescription = label, modifier = Modifier.fillMaxWidth().weight(1f), contentScale = ContentScale.Fit)
   else Box(Modifier.fillMaxWidth().weight(1f)) { Text("Sin foto", style = MaterialTheme.typography.bodySmall) }
  }
 }
}
