package com.numisfera.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [CoinEntity::class], version = 3, exportSchema = false)
abstract class NumisferaDatabase : RoomDatabase() {
    abstract fun coinDao(): CoinDao

    companion object {
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                val textFields = listOf(
                    "currencySystem", "issueDate", "diameterMm", "weightGrams", "thicknessMm", "edge", "shape",
                    "mint", "mintage", "designer", "technique", "orientation", "variety", "rarity", "acquisitionDate",
                    "acquisitionPrice", "acquisitionCurrency", "provenance", "valuationDate", "valuationSource",
                    "authenticity", "gradeScale", "referenceSource"
                )
                textFields.forEach { field ->
                    val default = if (field == "acquisitionCurrency") "ARS" else if (field == "authenticity") "Sin verificar" else ""
                    db.execSQL("ALTER TABLE coins ADD COLUMN `$field` TEXT NOT NULL DEFAULT '$default'")
                }
                db.execSQL("ALTER TABLE coins ADD COLUMN `isCommemorative` INTEGER NOT NULL DEFAULT 0")
            }
        }

        @Volatile private var instance: NumisferaDatabase? = null
        fun get(context: Context): NumisferaDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, NumisferaDatabase::class.java, "numisfera.db")
                .addMigrations(MIGRATION_2_3)
                .fallbackToDestructiveMigration()
                .build().also { instance = it }
        }
    }
}
