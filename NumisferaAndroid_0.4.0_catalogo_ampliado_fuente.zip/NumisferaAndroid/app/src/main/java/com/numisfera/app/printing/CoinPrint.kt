package com.numisfera.app.printing
import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import com.numisfera.app.data.CoinEntity
import java.io.File
object CoinPrint {
 private fun esc(s: String) = s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;")
 private fun photo(path: String, label: String): String {
  val f = File(path)
  return if (path.isNotBlank() && f.exists()) "<div class='photo'><strong>$label</strong><br><img src='file://${f.absolutePath}'></div>" else "<div class='photo'><strong>$label</strong><p>Sin fotografía</p></div>"
 }
 fun print(context: Context, c: CoinEntity) {
  val w = WebView(context)
  w.settings.javaScriptEnabled = false
  w.settings.allowFileAccess = true
  w.webViewClient = object : WebViewClient() {
   override fun onPageFinished(view: WebView, url: String) {
    val pm = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
    pm.print("Numisfera - ${c.name}", view.createPrintDocumentAdapter("Numisfera-${c.id}"),
     PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build())
   }
  }
  val html = "<html><head><meta charset=\"utf-8\"><style>@page{size:A4;margin:14mm}" +
   "body{font-family:Arial;color:#18212b;margin:18px}h1{color:#145c54;border-bottom:3px solid #145c54;padding-bottom:12px}" +
   "table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:8px;border:1px solid #ccd5d5}th{background:#edf3f2;width:32%}" +
   ".photos{display:flex;gap:14px;margin:14px 0}.photo{width:48%;border:1px solid #ccd5d5;padding:8px;box-sizing:border-box}.photo img{width:100%;height:170px;object-fit:contain;margin-top:8px}" +
   ".note{border:1px solid #ccd5d5;padding:12px;min-height:60px;white-space:pre-wrap}footer{margin-top:20px;font-size:10px;color:#566}</style></head><body>" +
   "<h1>NUMISFERA</h1><p>Ficha profesional de colección numismática</p><h2>${esc(c.name)}</h2>" +
   "<div class='photos'>${photo(c.obverseImagePath, "ANVERSO")}${photo(c.reverseImagePath, "REVERSO")}</div><table>" +
   row("País / autoridad",c.country) + row("Año / período",c.year) + row("Denominación",c.denomination) +
   row("Sistema monetario",c.currencySystem) + row("Fecha de emisión",c.issueDate) +
   row("Metal / composición",c.metal) + row("Diámetro (mm)",c.diameterMm) + row("Peso (g)",c.weightGrams) +
   row("Grosor (mm)",c.thicknessMm) + row("Canto",c.edge) + row("Forma",c.shape) +
   row("Ceca / autoridad acuñadora",c.mint) + row("Tirada",c.mintage) + row("Diseñador / grabador",c.designer) +
   row("Técnica",c.technique) + row("Orientación",c.orientation) + row("Variante",c.variety) +
   row("Rareza",c.rarity) + row("Conservación",c.conditionGrade) + row("Escala de conservación",c.gradeScale) +
   row("Autenticidad",c.authenticity) + row("Conmemorativa",if (c.isCommemorative) "Sí" else "No / no indicado") +
   row("Adquisición", "${c.acquisitionDate} · ${c.acquisitionPrice} ${c.acquisitionCurrency}") +
   row("Procedencia",c.provenance) + row("Valor registrado", "${c.estimatedValue} ${c.valueCurrency}") +
   row("Fecha de valoración",c.valuationDate) + row("Fuente de valoración",c.valuationSource) +
   row("Referencia de catálogo",c.catalogReference) + row("Fuente técnica",c.referenceSource) +
   "</table><h3>Descripción y observaciones</h3><div class='note'>${esc(c.notes.ifBlank { "Sin observaciones registradas." })}</div>" +
   "<footer>El valor registrado es orientativo y no constituye tasación certificada. La autenticidad y conservación requieren evaluación especializada.</footer></body></html>"
  w.loadDataWithBaseURL("file:///", html, "text/html", "UTF-8", null)
 }
 private fun row(label: String, value: String) = "<tr><th>${esc(label)}</th><td>${esc(value.ifBlank { "No consignado" })}</td></tr>"
}
