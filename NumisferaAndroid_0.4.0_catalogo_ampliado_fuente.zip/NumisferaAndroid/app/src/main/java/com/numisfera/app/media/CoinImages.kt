package com.numisfera.app.media

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/** Copies selected photos into app-private storage, so they remain available offline. */
object CoinImages {
    fun copyIntoAppStorage(context: Context, uri: Uri, side: String): String {
        val folder = File(context.filesDir, "coin_photos").apply { mkdirs() }
        val target = File(folder, "${side}_${UUID.randomUUID()}.jpg")
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "No se pudo abrir la imagen seleccionada." }
            FileOutputStream(target).use { output -> input.copyTo(output) }
        }
        return target.absolutePath
    }
}
