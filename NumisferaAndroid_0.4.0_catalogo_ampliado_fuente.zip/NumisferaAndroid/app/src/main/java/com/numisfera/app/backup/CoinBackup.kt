package com.numisfera.app.backup

import android.content.Context
import android.net.Uri
import com.numisfera.app.data.CoinEntity
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Base64

/**
 * JSON backup includes coin fields and embedded photo bytes (Base64), making
 * the backup portable to another installation. Keep the file in a safe place.
 */
object CoinBackup {
    suspend fun export(context: Context, coins: List<CoinEntity>, destination: Uri) {
        val array = JSONArray()
        coins.forEach { c ->
            array.put(JSONObject().apply {
                put("name", c.name); put("country", c.country); put("year", c.year)
                put("denomination", c.denomination); put("metal", c.metal)
                put("conditionGrade", c.conditionGrade); put("estimatedValue", c.estimatedValue)
                put("valueCurrency", c.valueCurrency); put("notes", c.notes)
                put("catalogReference", c.catalogReference)
                put("currencySystem", c.currencySystem); put("issueDate", c.issueDate)
                put("diameterMm", c.diameterMm); put("weightGrams", c.weightGrams); put("thicknessMm", c.thicknessMm)
                put("edge", c.edge); put("shape", c.shape); put("mint", c.mint); put("mintage", c.mintage)
                put("designer", c.designer); put("technique", c.technique); put("orientation", c.orientation)
                put("variety", c.variety); put("rarity", c.rarity); put("acquisitionDate", c.acquisitionDate)
                put("acquisitionPrice", c.acquisitionPrice); put("acquisitionCurrency", c.acquisitionCurrency)
                put("provenance", c.provenance); put("valuationDate", c.valuationDate); put("valuationSource", c.valuationSource)
                put("authenticity", c.authenticity); put("gradeScale", c.gradeScale); put("referenceSource", c.referenceSource)
                put("isCommemorative", c.isCommemorative)
                put("createdAt", c.createdAt)
                put("updatedAt", c.updatedAt)
                put("obverseImage", imageAsBase64(c.obverseImagePath))
                put("reverseImage", imageAsBase64(c.reverseImagePath))
            })
        }
        val root = JSONObject().put("app", "Numisfera").put("backupVersion", 1)
            .put("createdAt", System.currentTimeMillis()).put("coins", array)
        context.contentResolver.openOutputStream(destination, "w").use { stream ->
            requireNotNull(stream) { "No se pudo crear el archivo de copia." }
            stream.writer(Charsets.UTF_8).use { it.write(root.toString(2)) }
        }
    }

    suspend fun import(context: Context, source: Uri, save: suspend (CoinEntity) -> Long) {
        val json = context.contentResolver.openInputStream(source).use { stream ->
            requireNotNull(stream) { "No se pudo leer el archivo seleccionado." }
            JSONObject(stream.reader(Charsets.UTF_8).readText())
        }
        require(json.optString("app") == "Numisfera") { "El archivo no parece una copia de Numisfera." }
        val coins = json.getJSONArray("coins")
        for (i in 0 until coins.length()) {
            val c = coins.getJSONObject(i)
            val obverse = saveImage(context, c.optString("obverseImage"))
            val reverse = saveImage(context, c.optString("reverseImage"))
            save(CoinEntity(
                name = c.optString("name", "Moneda importada"),
                country = c.optString("country"), year = c.optString("year"),
                denomination = c.optString("denomination"), metal = c.optString("metal"),
                conditionGrade = c.optString("conditionGrade"), estimatedValue = c.optString("estimatedValue"),
                valueCurrency = c.optString("valueCurrency", "ARS"), notes = c.optString("notes"),
                catalogReference = c.optString("catalogReference"),
                currencySystem = c.optString("currencySystem"), issueDate = c.optString("issueDate"),
                diameterMm = c.optString("diameterMm"), weightGrams = c.optString("weightGrams"), thicknessMm = c.optString("thicknessMm"),
                edge = c.optString("edge"), shape = c.optString("shape"), mint = c.optString("mint"), mintage = c.optString("mintage"),
                designer = c.optString("designer"), technique = c.optString("technique"), orientation = c.optString("orientation"),
                variety = c.optString("variety"), rarity = c.optString("rarity"), acquisitionDate = c.optString("acquisitionDate"),
                acquisitionPrice = c.optString("acquisitionPrice"), acquisitionCurrency = c.optString("acquisitionCurrency", "ARS"),
                provenance = c.optString("provenance"), valuationDate = c.optString("valuationDate"), valuationSource = c.optString("valuationSource"),
                authenticity = c.optString("authenticity", "Sin verificar"), gradeScale = c.optString("gradeScale"),
                referenceSource = c.optString("referenceSource"), isCommemorative = c.optBoolean("isCommemorative", false),
                obverseImagePath = obverse, reverseImagePath = reverse
            ))
        }
    }

    private fun imageAsBase64(path: String): String {
        if (path.isBlank()) return ""
        val file = File(path)
        if (!file.exists()) return ""
        return Base64.getEncoder().encodeToString(file.readBytes())
    }

    private fun saveImage(context: Context, encoded: String): String {
        if (encoded.isBlank()) return ""
        val bytes = Base64.getDecoder().decode(encoded)
        val dir = File(context.filesDir, "coin_photos").apply { mkdirs() }
        val file = File(dir, "restored_${System.currentTimeMillis()}_${(1000..9999).random()}.jpg")
        file.writeBytes(bytes)
        return file.absolutePath
    }
}
