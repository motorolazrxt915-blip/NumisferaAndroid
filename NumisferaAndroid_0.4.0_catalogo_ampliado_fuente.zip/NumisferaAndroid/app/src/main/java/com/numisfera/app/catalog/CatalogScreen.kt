package com.numisfera.app.catalog

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.platform.LocalUriHandler
import com.numisfera.app.data.CoinEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CatalogScreen(onDismiss: () -> Unit, onAdd: (CoinEntity) -> Unit) {
    var search by remember { mutableStateOf("") }
    var country by remember { mutableStateOf("") }
    var period by remember { mutableStateOf("") }
    var denomination by remember { mutableStateOf("") }
    var metal by remember { mutableStateOf("") }
    val uriHandler = LocalUriHandler.current
    val results = remember(search, country, period, denomination, metal) {
        CoinCatalog.entries.filter { coin ->
            val allText = listOf(coin.name, coin.country, coin.period, coin.denomination, coin.metal, coin.reference, coin.description).joinToString(" ")
            (search.isBlank() || allText.contains(search.trim(), ignoreCase = true)) &&
                (country.isBlank() || coin.country.contains(country, ignoreCase = true)) &&
                (period.isBlank() || coin.period.contains(period, ignoreCase = true)) &&
                (denomination.isBlank() || coin.denomination.contains(denomination, ignoreCase = true) || coin.name.contains(denomination, ignoreCase = true)) &&
                (metal.isBlank() || coin.metal.contains(metal, ignoreCase = true))
        }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxWidth(0.96f).fillMaxHeight(0.94f), shape = MaterialTheme.shapes.extraLarge, tonalElevation = 6.dp) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text("Catálogo numismático", style = MaterialTheme.typography.headlineSmall)
                        Text("Catálogo sin conexión · ${CoinCatalog.entries.size} tipos", style = MaterialTheme.typography.bodySmall)
                        Text("Fuentes BCRA revisadas: 27/10/2026", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                    TextButton(onClick = onDismiss) { Text("Cerrar") }
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Actualización BCRA", style = MaterialTheme.typography.titleSmall)
                        Text("La moneda de plata del Mundial FIFA 2026 figura no disponible; el stand oficial indica que las 2.500 piezas locales se agotaron. Las Series Iberoamericanas y la moneda por los 40 años de la restauración democrática figuran disponibles en el listado general. El stock puede cambiar.", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { uriHandler.openUri("https://www.bcra.gob.ar/emisiones-conmemorativas/") }) { Text("Emisiones BCRA") }
                            TextButton(onClick = { uriHandler.openUri("https://www.bcra.gob.ar/stand-de-emisiones-numismaticas/") }) { Text("Stock / stand") }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Buscar por país, nombre, año o referencia") }, singleLine = true)
                Text("Filtros (opcionales)", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
                Column(Modifier.heightIn(max = 210.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    OutlinedTextField(country, { country = it }, modifier = Modifier.fillMaxWidth(), label = { Text("País (ej. Argentina)") }, singleLine = true)
                    OutlinedTextField(period, { period = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Año o período (ej. 1992)") }, singleLine = true)
                    OutlinedTextField(denomination, { denomination = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Denominación (ej. 1 peso)") }, singleLine = true)
                    OutlinedTextField(metal, { metal = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Metal (ej. cobre)") }, singleLine = true)
                    if (country.isNotBlank() || period.isNotBlank() || denomination.isNotBlank() || metal.isNotBlank() || search.isNotBlank()) {
                        TextButton(onClick = { search = ""; country = ""; period = ""; denomination = ""; metal = "" }) { Text("Limpiar filtros") }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("${results.size} resultado(s)", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                if (results.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = androidx.compose.ui.Alignment.Center) { Text("No hay coincidencias. Probá quitar algún filtro.") }
                } else LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(results, key = { "${it.country}-${it.name}-${it.period}-${it.reference}" }) { coin ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(coin.name, style = MaterialTheme.typography.titleMedium)
                                Text("${coin.country} · ${coin.period} · ${coin.denomination}", style = MaterialTheme.typography.bodyMedium)
                                Text("Sistema monetario: ${coin.currencySystem.ifBlank { "No indicado" }}", style = MaterialTheme.typography.bodySmall)
                                Text("Metal: ${coin.metal}", style = MaterialTheme.typography.bodySmall)
                                val technical = listOf(
                                    if (coin.diameterMm.isNotBlank()) "Diámetro ${coin.diameterMm} mm" else "",
                                    if (coin.weightGrams.isNotBlank()) "Peso ${coin.weightGrams} g" else "",
                                    if (coin.thicknessMm.isNotBlank()) "Grosor ${coin.thicknessMm} mm" else "",
                                    if (coin.edge.isNotBlank()) "Canto ${coin.edge}" else "",
                                    if (coin.shape.isNotBlank()) "Forma ${coin.shape}" else ""
                                ).filter { it.isNotBlank() }.joinToString(" · ")
                                if (technical.isNotBlank()) Text(technical, style = MaterialTheme.typography.bodySmall)
                                if (coin.commemorative) Text("Emisión conmemorativa", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                                Text("Referencia: ${coin.reference}", style = MaterialTheme.typography.bodySmall)
                                Text(coin.description, style = MaterialTheme.typography.bodySmall)
                                if (coin.referenceSource.isNotBlank()) Text("Fuente: ${coin.referenceSource}", style = MaterialTheme.typography.labelSmall)
                                Button(onClick = { onAdd(coin.toCollectionCoin()) }, modifier = Modifier.fillMaxWidth()) { Text("Agregar a mi colección") }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text("Importante: catálogo de referencia inicial, no exhaustivo. Los campos técnicos no confirmados se dejan vacíos; verificá la variante física y la fuente antes de usar datos para tasar.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
