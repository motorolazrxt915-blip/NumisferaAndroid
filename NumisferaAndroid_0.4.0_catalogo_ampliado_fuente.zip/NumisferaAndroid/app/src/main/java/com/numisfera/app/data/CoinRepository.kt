package com.numisfera.app.data
import kotlinx.coroutines.flow.Flow
class CoinRepository(private val dao: CoinDao) {
 fun observeCoins(): Flow<List<CoinEntity>> = dao.observeAll()
 suspend fun save(coin: CoinEntity): Long = dao.upsert(coin.copy(updatedAt = System.currentTimeMillis()))
 suspend fun delete(id: Long) = dao.deleteById(id)
}
