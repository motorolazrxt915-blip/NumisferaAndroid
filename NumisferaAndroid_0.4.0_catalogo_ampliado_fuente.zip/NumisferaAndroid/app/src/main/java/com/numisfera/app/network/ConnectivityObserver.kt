package com.numisfera.app.network
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
class ConnectivityObserver(context: Context) {
 private val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
 fun observe(): Flow<Boolean> = callbackFlow {
  fun connected(): Boolean {
   val n = manager.activeNetwork ?: return false
   val c = manager.getNetworkCapabilities(n) ?: return false
   return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
  }
  trySend(connected())
  val cb = object : ConnectivityManager.NetworkCallback() {
   override fun onAvailable(network: Network) { trySend(connected()) }
   override fun onLost(network: Network) { trySend(connected()) }
   override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { trySend(connected()) }
  }
  manager.registerNetworkCallback(NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), cb)
  awaitClose { runCatching { manager.unregisterNetworkCallback(cb) } }
 }
}
