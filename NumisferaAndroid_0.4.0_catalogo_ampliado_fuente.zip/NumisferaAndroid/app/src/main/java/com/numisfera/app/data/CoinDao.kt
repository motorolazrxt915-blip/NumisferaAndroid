package com.numisfera.app.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao interface CoinDao {
 @Query("SELECT * FROM coins ORDER BY country COLLATE NOCASE, year DESC, name COLLATE NOCASE")
 fun observeAll(): Flow<List<CoinEntity>>
 @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(coin: CoinEntity): Long
 @Query("DELETE FROM coins WHERE id = :id") suspend fun deleteById(id: Long)
 @Query("SELECT COUNT(*) FROM coins") fun observeCount(): Flow<Int>
}
