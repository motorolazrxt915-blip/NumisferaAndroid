package com.numisfera.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "coins")
data class CoinEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val country: String = "",
    val year: String = "",
    val denomination: String = "",
    val metal: String = "",
    val conditionGrade: String = "",
    val estimatedValue: String = "",
    val valueCurrency: String = "ARS",
    val notes: String = "",
    val catalogReference: String = "",
    val obverseImagePath: String = "",
    val reverseImagePath: String = "",
    // Professional numismatic record. Text fields preserve uncertain/varied source formats.
    val currencySystem: String = "",
    val issueDate: String = "",
    val diameterMm: String = "",
    val weightGrams: String = "",
    val thicknessMm: String = "",
    val edge: String = "",
    val shape: String = "",
    val mint: String = "",
    val mintage: String = "",
    val designer: String = "",
    val technique: String = "",
    val orientation: String = "",
    val variety: String = "",
    val rarity: String = "",
    val acquisitionDate: String = "",
    val acquisitionPrice: String = "",
    val acquisitionCurrency: String = "ARS",
    val provenance: String = "",
    val valuationDate: String = "",
    val valuationSource: String = "",
    val authenticity: String = "Sin verificar",
    val gradeScale: String = "",
    val referenceSource: String = "",
    val isCommemorative: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
